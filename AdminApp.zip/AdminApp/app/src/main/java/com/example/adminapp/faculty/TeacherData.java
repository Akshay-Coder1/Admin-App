package com.example.adminapp.faculty;

public class TeacherData {
    private String name, image, email, post, key;

    public TeacherData() {
    }

    public TeacherData(String name, String image, String email, String post, String key) {
        this.name = name;
        this.image = image;
        this.email = email;
        this.post = post;
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
