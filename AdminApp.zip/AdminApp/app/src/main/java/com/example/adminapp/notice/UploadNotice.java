package com.example.adminapp.notice;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


import com.example.adminapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class UploadNotice extends AppCompatActivity {
    private Button mbtn_upload_notice;
    private EditText noticeTitle;
    MaterialCardView mcv_notice;
    private final int REQ = 1;
    private Bitmap bitmap;
    private ImageView notice_Imageview;
    private DatabaseReference reference, dbRef;
    private StorageReference storageReference;
    private ProgressDialog pd;
    String downloadUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();  // to hide the name of app
        setContentView(R.layout.activity_upload_notice);

        reference = FirebaseDatabase.getInstance().getReference();
        storageReference = FirebaseStorage.getInstance().getReference();

        pd = new ProgressDialog(this);

        mcv_notice = findViewById(R.id.mcv_notice);
        notice_Imageview = findViewById(R.id.iv_notice_imageviewer);
        noticeTitle = findViewById(R.id.noticeTitle);
        mbtn_upload_notice = findViewById(R.id.mbtn_upload_notice);

        mbtn_upload_notice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mbtn_upload_notice.getText().toString().isEmpty())
                {
                    mbtn_upload_notice.setError("Empty");
                    mbtn_upload_notice.requestFocus();
                }

                else if(bitmap == null)
                {
                    uploadData();
                }
                else{
                    uploadImage();
                }
            }
        });
        mcv_notice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });
    }
    private void uploadImage() {
        // Check if title is empty
        String title = noticeTitle.getText().toString().trim();
        if (title.isEmpty()) {
            noticeTitle.setError("Please enter a title for the notice");
            noticeTitle.requestFocus();
            return; // Stop further execution if title is empty
        }

        // Check if image is selected
        if (bitmap == null) {
            Toast.makeText(UploadNotice.this, "Please select an image for the notice", Toast.LENGTH_SHORT).show();
            return; // Stop further execution if image is not selected
        }

        pd.setMessage("Uploading Image...");
        pd.show();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        byte[] finalimg = baos.toByteArray();

        final StorageReference filepath = storageReference.child("Notice").child(System.currentTimeMillis() + ".jpg");

        final UploadTask uploadTask = filepath.putBytes(finalimg);
        uploadTask.addOnCompleteListener(UploadNotice.this, new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                if (task.isSuccessful()) {
                    uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            filepath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    downloadUrl = uri.toString();
                                    uploadData(); // Proceed to upload data
                                }
                            });
                        }
                    });
                } else {
                    pd.dismiss();
                    Toast.makeText(UploadNotice.this, "Something went wrong during image upload", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void uploadData() {
        // Validate the title again in case of any issues
        String title = noticeTitle.getText().toString().trim();
        if (title.isEmpty()) {
            noticeTitle.setError("Please enter a title for the notice");
            noticeTitle.requestFocus();
            return; // Stop further execution if title is empty
        }
        if (bitmap == null) {
            Toast.makeText(UploadNotice.this, "Please select an image for the notice", Toast.LENGTH_SHORT).show();
            return; // Stop further execution if image is not selected
        }

        dbRef = reference.child("Notice");
        final String uniqueKey = dbRef.push().getKey();

        Calendar calfordate = Calendar.getInstance();
        SimpleDateFormat currentdate = new SimpleDateFormat("dd-MM-yy");
        String date = currentdate.format(calfordate.getTime());

        Calendar calfortime = Calendar.getInstance();
        SimpleDateFormat currenttime = new SimpleDateFormat("hh:mm a");
        String time = currenttime.format(calfortime.getTime());

        NoticeData noticeData = new NoticeData(title, downloadUrl, date, time, uniqueKey);

        dbRef.child(uniqueKey).setValue(noticeData).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                    pd.dismiss(); // Dismiss the progress dialog after successful upload
                    Toast.makeText(UploadNotice.this, "Notice Uploaded Successfully", Toast.LENGTH_SHORT).show();

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                pd.dismiss(); // Dismiss the progress dialog on failure
                Toast.makeText(UploadNotice.this, "Something Went Wrong, Notice not Uploaded", Toast.LENGTH_SHORT).show();
            }
        });
    }





    private void openGallery() {
        Intent i4 = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i4, REQ);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQ && resultCode == RESULT_OK)
        {
            Uri uri = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            notice_Imageview.setImageBitmap(bitmap);
        }
    }

}
