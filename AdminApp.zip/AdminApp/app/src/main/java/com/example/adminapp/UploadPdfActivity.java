package com.example.adminapp;

import static android.content.Intent.createChooser;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

public class UploadPdfActivity extends AppCompatActivity {

    private Button mbtn_upload_pdf;
    private EditText pdfTitle;
    MaterialCardView mcv_pdf;
    private TextView pdftextview;
    private final int REQ = 1;
    private Uri pdfdata;
    private ImageView pdf_Imageview;
    private DatabaseReference  databaseReference;
    private StorageReference storageReference;

    private String pdfname;
    private  String title;
    private ProgressDialog pd;
    String downloadUrl = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_upload_pdf);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        storageReference = FirebaseStorage.getInstance().getReference();

        pd = new ProgressDialog(this);

        mcv_pdf = findViewById(R.id.addPDF);
        pdfTitle = findViewById(R.id.pdfTitle);
        mbtn_upload_pdf = findViewById(R.id.mbtn_upload_pdf);
        pdftextview = findViewById(R.id.pdftextView);

        mbtn_upload_pdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               title = pdfTitle.getText().toString();
               if(title.isEmpty()) {
                   pdfTitle.setError("Empty");
                   pdfTitle.requestFocus();
               }
               else if(pdfdata == null) {
                   Toast.makeText(UploadPdfActivity.this, "Please upload pdf", Toast.LENGTH_SHORT).show();
               }
               else {
                   uploadPdf();
               }

            }
        });
        mcv_pdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

    }

    private void uploadPdf() {
        pd.setTitle("Please wait...");
        pd.setMessage("Uploading pdf");
        pd.show();
        StorageReference reference = storageReference.child("pdf/"+ pdfname+"-"+System.currentTimeMillis()+".pdf");
        reference.putFile(pdfdata)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                        while (!uriTask.isComplete());
                        Uri uri = uriTask.getResult();
                        uploadData(String.valueOf(uri));
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pd.dismiss();
                        Toast.makeText(UploadPdfActivity.this, "Something went Wrong", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void uploadData(String s) {
        String uniquekey = databaseReference.child("pdf").push().getKey();
        HashMap data = new HashMap();
        data.put("pdfTitle", title);
        data.put("pdfUrl", s);

        databaseReference.child("pdf").child(uniquekey).setValue(data).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                pd.dismiss();
                Toast.makeText(UploadPdfActivity.this, "PDF uploaded successfully", Toast.LENGTH_SHORT).show();
                pdfTitle.setText("");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                pd.dismiss();
                Toast.makeText(UploadPdfActivity.this, "Failed to upload pdf", Toast.LENGTH_SHORT).show();
            }
        });
    }

//    private void openGallery() {
//        Intent intent = new Intent();
//        intent.setType("pdf/docs/ppt");
//       // intent.setType(*);// if not work then use "*"
//        intent.setAction(Intent.ACTION_GET_CONTENT);
//        startActivityForResult(createChooser(intent, "Select PDF File"), REQ);
//    }
private void openGallery() {
    Intent intent = new Intent();
    intent.setType("*/*"); // General file selection
    String[] mimeTypes = {
            "application/pdf", // PDF files
            "application/msword", // Word DOC files
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", // Word DOCX files
            "application/vnd.ms-powerpoint", // PowerPoint PPT files
            "application/vnd.openxmlformats-officedocument.presentationml.presentation" // PowerPoint PPTX files
    };
    intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes); // Specify allowed types
    intent.setAction(Intent.ACTION_GET_CONTENT);
    startActivityForResult(Intent.createChooser(intent, "Select a File"), REQ);
}


    @SuppressLint("Range")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQ && resultCode == RESULT_OK)
        {
           pdfdata = data.getData();
           if(pdfdata.toString().startsWith("content://")) {
               Cursor cursor = null;
               try {
                   cursor = UploadPdfActivity.this.getContentResolver().query(pdfdata, null, null, null, null);
                   if(cursor != null && cursor.moveToFirst()) {
                       pdfname = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                   }
               } catch (Exception e) {
                   throw new RuntimeException(e);
               }
           }
           else if (pdfdata.toString().startsWith("file://")) {
               pdfname = new File(pdfdata.toString()).getName();
           }
           pdftextview.setText(pdfname);
        }
    }
}