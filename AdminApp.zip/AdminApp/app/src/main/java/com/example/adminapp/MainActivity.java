package com.example.adminapp;

import com.example.adminapp.faculty.UpdateFaculty;
import com.example.adminapp.notice.DeleteNoticeActivity;
import com.example.adminapp.notice.UploadNotice;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

//import com.example.adminapp.faculty.AddTeacher;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    CardView uploadNotice,addGalleryImage,addEbook,addFaculty, deleteNotice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        requestWindowFeature(Window. FEATURE_NO_TITLE);
//        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);


        uploadNotice=findViewById(R.id.addNotice);
        addGalleryImage=findViewById(R.id.addGalleryImage);
        addEbook=findViewById(R.id.addEbook);
        addFaculty=findViewById(R.id.addFaculty);
        deleteNotice = findViewById(R.id.deleteNotice);

        uploadNotice.setTranslationY(2000);
// Animate to normal position
        uploadNotice.animate()
                .translationY(0)
                .setDuration(2500)
                .setStartDelay(400)
                .start();

        addGalleryImage.setTranslationY(2000);
// Animate to normal position
        addGalleryImage.animate()
                .translationY(0)
                .setDuration(2500)
                .setStartDelay(400)
                .start();

        addEbook.setTranslationY(2000);
// Animate to normal position
        addEbook.animate()
                .translationY(0)
                .setDuration(2500)
                .setStartDelay(400)
                .start();

        addFaculty.setTranslationY(2000);
// Animate to normal position
        addFaculty.animate()
                .translationY(0)
                .setDuration(2500)
                .setStartDelay(400)
                .start();

        deleteNotice.setTranslationY(2000);
// Animate to normal position
        deleteNotice.animate()
                .translationY(0)
                .setDuration(2500)
                .setStartDelay(400)
                .start();



        deleteNotice.setOnClickListener(this);
        uploadNotice.setOnClickListener(this);
        addGalleryImage.setOnClickListener(this);
        addEbook.setOnClickListener(this);
        addFaculty.setOnClickListener(this);



    }


    @Override
    public void onClick(View view) {
        switch(view.getId()) {

            case R.id.addNotice:
                Intent intent = new Intent(MainActivity.this, UploadNotice.class);
                startActivity(intent);
                break;

            case R.id.addGalleryImage:
                Intent intent2=new Intent(MainActivity.this,UploadImage.class);
                startActivity(intent2);
                break;
            case R.id.addEbook:
                Intent intent3=new Intent(MainActivity.this,UploadPdfActivity.class);
                startActivity(intent3);
                break;
            case R.id.addFaculty:
                Intent intent4 = new Intent(MainActivity.this, UpdateFaculty.class);
                startActivity(intent4);
                break;

            case R.id.deleteNotice:
                Intent intent5 = new Intent(MainActivity.this, DeleteNoticeActivity.class);
                startActivity(intent5);
                break;
            }
        }
}