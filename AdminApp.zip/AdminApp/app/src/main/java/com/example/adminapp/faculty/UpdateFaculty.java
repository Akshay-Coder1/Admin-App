package com.example.adminapp.faculty;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.adminapp.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class UpdateFaculty extends AppCompatActivity {

    FloatingActionButton fab;

    private RecyclerView csDepartment, itDepartment, cvDepartment, entcDepartment, meDepartment, otherDepartment;
    private LinearLayout csNoData, itNoData, cvNoData, entcNoData, meNoData, otherNoData;
    private List<TeacherData> list1, list2, list3, list4, list5, list6;
    private DatabaseReference reference, dbRef;
    private TeacherAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_update_faculty);

        fab = findViewById(R.id.fab);

        csDepartment = findViewById(R.id.csDepartment);
        itDepartment = findViewById(R.id.itDepartment);
        cvDepartment = findViewById(R.id.cvDepartment);
        entcDepartment = findViewById(R.id.entcDepartment);
        meDepartment = findViewById(R.id.meDepartment);
        otherDepartment = findViewById(R.id.otherDepartment);

        csNoData = findViewById(R.id.csNoData);
        itNoData = findViewById(R.id.itNoData);
        cvNoData = findViewById(R.id.cvNoData);
        entcNoData = findViewById(R.id.entcNoData);
        meNoData = findViewById(R.id.meNoData);
        otherNoData = findViewById(R.id.otherNoData);

        reference = FirebaseDatabase.getInstance().getReference().child("Teacher");


        csDepartment();
        itDepartment();
        cvDepartment();
        entcDepartment();
        meDepartment();
        otherDepartment();



        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UpdateFaculty.this, AddTeachers.class));
            }
        });

    }

    private void csDepartment() {

        dbRef = reference.child("Computer Engineering");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list1 = new ArrayList<>();
                if(!dataSnapshot.exists()) {
                    csNoData.setVisibility(View.VISIBLE);
                    csDepartment.setVisibility(View.GONE);
                }
                else {
                    csNoData.setVisibility(View.GONE);
                    csDepartment.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot: dataSnapshot.getChildren()) {
                        TeacherData data = snapshot.getValue(TeacherData.class);
                        list1.add(data);
                    }
                        csDepartment.setHasFixedSize(true);
                        csDepartment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                        adapter = new TeacherAdapter(list1, UpdateFaculty.this, "Computer Engineering");
                        csDepartment.setAdapter(adapter);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UpdateFaculty.this,"Database Error ",Toast.LENGTH_SHORT).show();
//                Toast.makeText(UpdateFaculty.this, databaseError.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void itDepartment() {

        dbRef = reference.child("Information Technology");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list2 = new ArrayList<>();
                if(!dataSnapshot.exists()) {
                    itNoData.setVisibility(View.VISIBLE);
                    itDepartment.setVisibility(View.GONE);
                }
                else {
                    itNoData.setVisibility(View.GONE);
                    itDepartment.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot: dataSnapshot.getChildren()) {
                        TeacherData data = snapshot.getValue(TeacherData.class);
                        list2.add(data);
                    }
                    itDepartment.setHasFixedSize(true);
                    itDepartment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter = new TeacherAdapter(list2, UpdateFaculty.this, "Information Technology");
                    itDepartment.setAdapter(adapter);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UpdateFaculty.this,"Database Error ",Toast.LENGTH_SHORT).show();
//                Toast.makeText(UpdateFaculty.this, databaseError.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void cvDepartment() {

        dbRef = reference.child("Civil Engineering");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list3 = new ArrayList<>();
                if(!dataSnapshot.exists()) {
                    cvNoData.setVisibility(View.VISIBLE);
                    cvDepartment.setVisibility(View.GONE);
                }
                else {
                    cvNoData.setVisibility(View.GONE);
                    cvDepartment.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot: dataSnapshot.getChildren()) {
                        TeacherData data = snapshot.getValue(TeacherData.class);
                        list3.add(data);
                    }
                        cvDepartment.setHasFixedSize(true);
                        cvDepartment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                        adapter = new TeacherAdapter(list3, UpdateFaculty.this, "Civil Engineering");
                        cvDepartment.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UpdateFaculty.this,"Database Error ",Toast.LENGTH_SHORT).show();
//                Toast.makeText(UpdateFaculty.this, databaseError.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void entcDepartment() {

        dbRef = reference.child("ENTC");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list4 = new ArrayList<>();
                if(!dataSnapshot.exists()) {
                    entcNoData.setVisibility(View.VISIBLE);
                    entcDepartment.setVisibility(View.GONE);
                }
                else {
                    entcNoData.setVisibility(View.GONE);
                    entcDepartment.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot: dataSnapshot.getChildren()) {
                        TeacherData data = snapshot.getValue(TeacherData.class);
                        list4.add(data);
                    }
                        entcDepartment.setHasFixedSize(true);
                        entcDepartment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                        adapter = new TeacherAdapter(list4, UpdateFaculty.this,"ENTC");
                        entcDepartment.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UpdateFaculty.this,"Database Error ",Toast.LENGTH_SHORT).show();
//                Toast.makeText(UpdateFaculty.this, databaseError.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void meDepartment() {

        dbRef = reference.child("Mechanical Engineering");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list5 = new ArrayList<>();
                if(!dataSnapshot.exists()) {
                    meNoData.setVisibility(View.VISIBLE);
                    meDepartment.setVisibility(View.GONE);
                }
                else {
                    meNoData.setVisibility(View.GONE);
                    meDepartment.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot: dataSnapshot.getChildren()) {
                        TeacherData data = snapshot.getValue(TeacherData.class);
                        list5.add(data);
                    }
                        meDepartment.setHasFixedSize(true);
                        meDepartment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                        adapter = new TeacherAdapter(list5, UpdateFaculty.this,"Mechanical Engineering");
                        meDepartment.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UpdateFaculty.this,"Database Error ",Toast.LENGTH_SHORT).show();
//                Toast.makeText(UpdateFaculty.this, databaseError.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void otherDepartment() {

        dbRef = reference.child("Other Branch");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list6 = new ArrayList<>();
                if(!dataSnapshot.exists()) {
                    otherNoData.setVisibility(View.VISIBLE);
                    otherDepartment.setVisibility(View.GONE);
                }
                else {
                    otherNoData.setVisibility(View.GONE);
                    otherDepartment.setVisibility(View.VISIBLE);
                    for(DataSnapshot snapshot: dataSnapshot.getChildren()) {
                        TeacherData data = snapshot.getValue(TeacherData.class);
                        list6.add(data);
                    }
                        otherDepartment.setHasFixedSize(true);
                        otherDepartment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                        adapter = new TeacherAdapter(list6, UpdateFaculty.this, "Other Branch");
                        otherDepartment.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UpdateFaculty.this,"Database Error ",Toast.LENGTH_SHORT).show();
//                Toast.makeText(UpdateFaculty.this, databaseError.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
}